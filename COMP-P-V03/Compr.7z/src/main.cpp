//Screen Control Functions
#include "ScreenMainFuncts.h"
//External Controls
#include "ControlsMain.h"
//Pong game
#include "PongGame.h"
//Menu
#include "Menu.h"
// ----- ON HOLD -----
//Comunication
//#include "Comms.h"

//Initialize PONG game
pongGAME game (10);

void setup() {
  //Initialize screen
  ST7565_init();
  //Initialize controls
  Controls_init();
  //Initialize Menu
  Menus_init();

  ST7565_Clearscreen(0);
}

void loop() {
  //TO ADD WITH INTERRUPTS to control
  game.actualizeGAME(Listen(1),Listen(2));
  //ST7565_HelloWorld();
  //Start/Update Game
  //game.actualizeGAME(Listen(1),Listen(2));

}
/*
int main(){
  setup();
  while(1){loop();}
}
//*/
