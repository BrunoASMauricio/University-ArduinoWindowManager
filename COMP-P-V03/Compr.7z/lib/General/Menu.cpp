#ifndef __Menu_cpp__
#define __Menu_cpp__

#include "Menu.h"
void Menus_init(){

}
#endif
