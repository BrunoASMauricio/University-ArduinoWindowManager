#ifndef __GeneralFunctions_h__
#define __GeneralFunctions_h__

#define uchar unsigned char


#include "GeneralFunctions.cpp"
#endif
